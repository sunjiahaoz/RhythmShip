﻿/*
IAttacker
By: @sunjiahaoz, 2016-4-7

可以进行攻击的entity
*/
using UnityEngine;
using System.Collections;

namespace sunjiahaoz.gamebase
{
    public class IAttackerEntity
    {
        // 用于进行攻击计算的属性
    }
}
