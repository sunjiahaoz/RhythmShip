﻿using UnityEngine;
using System.Collections;

public interface IRhythmShot {
    void OnRhythmShot();
}
