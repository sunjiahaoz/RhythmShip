﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using sunjiahaoz;

public class BaseEnemyShip : BaseShip{
    public List<EventDelegate> _lstOnShipCreateEvent;
    [Header("碰撞其他东西的时候")]
    public LayerMask _colliderLayer;
    public ColliderTrigger _trigger;
    public int _nHurtValue = 3;

    protected override void Awake()
    {
        base.Awake();
        _trigger._actionTriggerEnter = OnShipTriggerEnter;
    }

    public virtual void OnShipCreate(EnemyCreator creator)
    {        
        base.OnShipCreate();
        // 其他 todo
        EventDelegate.Execute(_lstOnShipCreateEvent);
    }

    void OnShipTriggerEnter(GameObject go)
    {
        if (ToolsUseful.CheckLayerContainedGo(_colliderLayer, go))
        {
            BaseLifeCom life = go.GetComponent<BaseLifeCom>();
            if (life != null)
            {
                life.AddValue(-_nHurtValue);
                _lifeCom.AddValue(-_nHurtValue);
            }
        }
    }
}
