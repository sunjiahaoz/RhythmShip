﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using sunjiahaoz;
using sunjiahaoz.SteerTrack;
using RUL;
using DG.Tweening;

public class EnemyShip_Rail : MonoBehaviour//BaseRhythmEnemyShip
{
    public bool _bDebugDraw = true;
    public ObjectAnim_FollowPath _trail;

    static Vector3 _leftTop = Vector3.zero;
    static Vector3 _rightBottom = Vector3.zero;
    static float _fMinIntervalDistWidth = 0;
    static float _fMinIntervalDistHeight = 0;

    List<Vector3> _lstTrailPos = new List<Vector3>();
    void Start()
    {
        _leftTop = GamingData.Instance.CamMgr.GetAnchorPos(CameraAnchorPos.LeftTop).position;
        _rightBottom = GamingData.Instance.CamMgr.GetAnchorPos(CameraAnchorPos.RightBottom).position;
        _fMinIntervalDistWidth = GamingData.Instance.CamMgr.GetWidthDistance() / 6;
        _fMinIntervalDistHeight = GamingData.Instance.CamMgr.GetHeightDistance() / 6;
    }

    public void RunTail()
    {
        GenerateRail();
        _trail.transform.position = _lstTrailPos[0];
        _trail.GetComponent<SplineTrailRenderer>().Clear();
        _trail._path = _lstTrailPos.ToArray();
        _trail.Run();
    }

    void GenerateRail()
    {
        _lstTrailPos.Clear();
        bool bH = Random.Range(0, 100) > 50 ? true : false;
        Vector3 pointA = GenerateRandomPointA();
        Vector3 PointB = GeneratePointB(pointA, bH);
        Vector3 pointStart = pointA;
        if (bH)
        {
            pointStart.y = _leftTop.y;
        }
        else
        {
            pointStart.x = _leftTop.x;
        }
        Vector3 pointEnd = PointB;
        if (bH)
        {
            pointEnd.y = _rightBottom.y;
        }
        else
        {
            pointEnd.x = _rightBottom.x;
        }
        _lstTrailPos.Add(pointStart);
        _lstTrailPos.Add(pointA);
        _lstTrailPos.Add(PointB);
        _lstTrailPos.Add(pointEnd);

        ToolsUseful.DebugOutList<Vector3>(_lstTrailPos);
    }    
    Vector3 GenerateRandomPointA()
    {
        Vector2 leftTop = _leftTop;
        // 取个比例，防止随机在边上
        leftTop.x += _fMinIntervalDistWidth;
        leftTop.y += _fMinIntervalDistHeight;
        Vector2 rightBottom = _rightBottom;
        rightBottom.x -= _fMinIntervalDistWidth;
        rightBottom.y -= _fMinIntervalDistHeight;
        return (RulVec.RandVector2(rightBottom.x, rightBottom.y, leftTop.x, leftTop.y));
    }
    Vector3 GeneratePointB(Vector3 pointA, bool bH)
    {
        Vector3 posB = Vector3.zero;
        posB.z = pointA.z;
        if (bH)
        {
            posB.y = pointA.y;

            float fX = Random.Range(_leftTop.x, _rightBottom.x);
            posB.x = fX;
        }
        else
        {
            posB.x = pointA.x;

            float fY = Random.Range(_rightBottom.y, _leftTop.y);
            posB.y = fY;
        }

        return posB;
    }
    void OnDrawGizmos()
    {
        if (_bDebugDraw)
        {
            for (int i = 0; i < _lstTrailPos.Count; ++i)
            {
                Gizmos.DrawSphere(_lstTrailPos[i], 50);
            }
        }        
    }
}
